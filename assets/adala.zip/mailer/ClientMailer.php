<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Load Composer's autoloader
require 'vendor/autoload.php';

$name = $_POST['name'];
$email = $_POST['email'];
$loan = $_POST['loan'];
$loan_num = $_POST['loan_num'];
$phone=$_POST['phone'];
$massage=$_POST['massage'];
$mail = new PHPMailer(true);

try {
  //Server settings
  //$mail->SMTPDebug = 2;
  $mail->isSMTP();  
  $mail->CharSet = 'UTF-8';
  $mail->Host       = 'mail.tamwel.us';
  $mail->Username = "contact@tamwel.us";
  $mail->Password = "khm123456";
  $mail->SMTPAuth = false;
  $mail->SMTPSecure = false;
  $mail->SMTPAutoTLS = false;
  $mail->Port       = 25;
  $mail->Encoding     = "base64";

  //Recipients
  $mail->setFrom('contact@tamwel.us', 'بيت التمويل والقروض الدولي');
  $mail->addAddress('khm.lowyer@gmail.com'); 

  // Content
  $mail->isHTML(true);
  $mail->Subject = 'عميل جديد';
  $mail->Body    = 'اسم العميل: ' . $name . '<br> اميل العميل: ' . $email . '<br>رقم هاتف العميل: ' . $phone . '<br>القرض: ' . $loan. '<br>المبلغ: ' . $loan_num;
  $mail->AltBody = 'new';
  if ($mail->send()) {
    header("Location: /ThankYouPage.html");
    }
   else {
    header("Location: /contact.html");
  }
} catch (Exception $e) {
  echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}